package com.viewnext.models;

import java.util.Arrays;
import java.util.List;

public class Datos {

	public static List<Pelicula> PELICULAS = Arrays.asList(new Pelicula(1L, "El 47"),
			new Pelicula(2L, "La Infiltrada"),
			new Pelicula(3L, "La habitacion de al lado"));
	
	public static List<Pelicula> PELICULAS_ID_NULL = Arrays.asList(new Pelicula(null, "El 47"),
			new Pelicula(null, "La Infiltrada"),
			new Pelicula(null, "La habitacion de al lado"));
	
	public static List<Pelicula> PELICULAS_ID_NEGATIVO = Arrays.asList(new Pelicula(-1L, "El 47"),
			new Pelicula(-2L, "La Infiltrada"),
			new Pelicula(-3L, "La habitacion de al lado"));
	
	
	public static List<String> ACTORES = Arrays.asList("Actor 1", "Actor 2", "Actor 3");
	
	public static Pelicula PELICULA = new Pelicula(null, "Harry Potter");
}
