package com.viewnext.repositories;

import java.util.List;

import com.viewnext.models.Datos;
import com.viewnext.models.Pelicula;

public class PeliculaRepositoryImpl implements PeliculaRepository{

	@Override
	public List<Pelicula> findAll() {
		System.out.println("Metodo findAll() de PeliculaRepositoryImpl");
//		return Arrays.asList(new Pelicula(1L, "El 47"),
//				new Pelicula(2L, "La Infiltrada"),
//				new Pelicula(3L, "La habitacion de al lado"));
		return Datos.PELICULAS;
	}

	@Override
	public Pelicula crear(Pelicula pelicula) {
		System.out.println("Metodo crear() de PeliculaRepositoryImpl");
		return Datos.PELICULA;
	}

}
