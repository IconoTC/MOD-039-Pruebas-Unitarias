package com.viewnext.repositories;

import java.util.List;

import com.viewnext.models.Datos;

public class ActorRepositoryImpl implements ActorRepository{

	@Override
	public List<String> findActoresByPeliculaId(Long id) {
		System.out.println("Metodo findActoresByPeliculaId() de ActorRepositoryImpl");
		return Datos.ACTORES;
	}

	@Override
	public void crearListaActores(List<String> actores) {
		System.out.println("Metodo crearListaActores() de ActorRepositoryImpl");
		
	}

}
