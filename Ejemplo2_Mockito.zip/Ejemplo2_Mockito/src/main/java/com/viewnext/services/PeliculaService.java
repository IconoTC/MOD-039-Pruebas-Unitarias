package com.viewnext.services;

import com.viewnext.models.Pelicula;

public interface PeliculaService {
	
	Pelicula findPeliculaByNombre(String nombre);
	
	Pelicula findPeliculaByNombreConActores(String nombre);
	
	Pelicula crear(Pelicula pelicula);

}
