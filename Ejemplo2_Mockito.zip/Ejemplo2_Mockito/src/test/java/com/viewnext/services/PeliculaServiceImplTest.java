package com.viewnext.services;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.viewnext.models.Pelicula;
import com.viewnext.repositories.ActorRepository;
import com.viewnext.repositories.PeliculaRepository;

public class PeliculaServiceImplTest {
	
	PeliculaRepository repository;
	PeliculaService service;
	ActorRepository actorRepository;
	
	@BeforeEach
	void inicioPrueba() {
		// Creo un mock (objeto ficticio del repository)
		// No se puede crear un mock de cualquier metodo, solo publicos o default
		// nunca de un metodo privado o estatico y tampoco final
		repository = Mockito.mock(PeliculaRepository.class);
		actorRepository = Mockito.mock(ActorRepository.class);
		service = new PeliculaServiceImpl(repository, actorRepository);
	}
	
	@Test
	void testFindPeliculaByNombre() {
		List<Pelicula> datos = Arrays.asList(new Pelicula(1L, "El 47"),
				new Pelicula(2L, "La Infiltrada"),
				new Pelicula(3L, "La habitacion de al lado"));
		
		// Cuando pedimos buscar todas las peliculas retornas datos
		Mockito.when(repository.findAll()).thenReturn(datos);
		
		Pelicula pelicula = service.findPeliculaByNombre("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
	}

}
