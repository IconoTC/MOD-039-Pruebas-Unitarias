package com.viewnext.services;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatcher;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;

import com.viewnext.models.Datos;
import com.viewnext.models.Pelicula;
import com.viewnext.repositories.ActorRepository;
import com.viewnext.repositories.ActorRepositoryImpl;
import com.viewnext.repositories.PeliculaRepository;
import com.viewnext.repositories.PeliculaRepositoryImpl;

@ExtendWith(MockitoExtension.class)
public class PeliculaServiceImplTest {
	
	// Para poder llamar al metodo real necesitamos tener la clase y no la interface
	//PeliculaRepository repository;
	@Mock
	PeliculaRepositoryImpl repository;
	
	@Mock
	ActorRepositoryImpl actorRepository;
	
	@InjectMocks
	PeliculaServiceImpl service;
	
	@Captor
	ArgumentCaptor<Long> captor;
	
	
	@BeforeEach
	void inicioPrueba() {
		// Creo un mock (objeto ficticio del repository)
		// No se puede crear un mock de cualquier metodo, solo publicos o default
		// nunca de un metodo privado o estatico y tampoco final
		//repository = Mockito.mock(PeliculaRepository.class);
		//actorRepository = Mockito.mock(ActorRepository.class);
		//service = new PeliculaServiceImpl(repository, actorRepository);
		
		// al usar anotaciones necesitamos activarlas:
		// tenemos 2 formas de hacerlo: programatica o con anotacion @ExtendWith
		//MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void testFindPeliculaByNombre() {
		// Cuando pedimos buscar todas las peliculas retornas datos
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		
		Pelicula pelicula = service.findPeliculaByNombre("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
	}
	
	@Test
	void testActoresPelicula() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorRepository.findActoresByPeliculaId(2L)).thenReturn(Datos.ACTORES);
		
		Pelicula pelicula = service.findPeliculaByNombreConActores("La Infiltrada");
		
		Assertions.assertEquals(3, pelicula.getActores().size());
	}
	
	// Con verify comprobamos que llamamos a determinados metodos del mock
	@Test
	void testActoresPeliculaVerify() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorRepository.findActoresByPeliculaId(2L)).thenReturn(Datos.ACTORES);
		
		Pelicula pelicula = service.findPeliculaByNombreConActores("La Infiltrada");
		
		//Assertions.assertEquals(3, pelicula.getActores().size());
		
		Mockito.verify(repository).findAll();
		Mockito.verify(actorRepository).findActoresByPeliculaId(2L);
	}
	
	@Test
	void testCrearPelicula() {
		// BDD (Behavior Driver Development) -> Desarrollo dirigido por comportamiento
		// 1.- Given (Preparacion)
		Pelicula peliculaNueva = Datos.PELICULA;
		peliculaNueva.setActores(Datos.ACTORES);
		
		Mockito.when(repository.crear(Mockito.any(Pelicula.class))).thenReturn(Datos.PELICULA);
		
		// 2.- When (Ejecucion)
		Pelicula pelicula = service.crear(peliculaNueva);
		
		// 3.- Then (Evaluar resultados)
		Assertions.assertNotNull(pelicula.getId());
		Assertions.assertEquals(4L, pelicula.getId());
		Assertions.assertEquals("Harry Potter", pelicula.getNombre());
		
		Mockito.verify(repository).crear(Mockito.any(Pelicula.class));  // crear una instancia falsa de pelicula
		Mockito.verify(actorRepository).crearListaActores(Mockito.anyList());  // crear una lista falsa
	}
	
	@Test
	void testCrearPeliculaIncremental() {
		// BDD (Behavior Driver Development) -> Desarrollo dirigido por comportamiento
		// 1.- Given (Preparacion)
		Pelicula peliculaNueva = Datos.PELICULA;
		peliculaNueva.setActores(Datos.ACTORES);
		
		Mockito.when(repository.crear(Mockito.any(Pelicula.class))).then(new Answer<Pelicula>() {
			
			Long secuencia = 4L;

			@Override
			public Pelicula answer(InvocationOnMock invocation) throws Throwable {
				Pelicula pelicula = invocation.getArgument(0);
				pelicula.setId(secuencia++);
				return pelicula;
			}
		});
		
		// 2.- When (Ejecucion)
		Pelicula pelicula = service.crear(peliculaNueva);
		
		// 3.- Then (Evaluar resultados)
		Assertions.assertNotNull(pelicula.getId());
		Assertions.assertEquals(4L, pelicula.getId());
		Assertions.assertEquals("Harry Potter", pelicula.getNombre());
		
		Mockito.verify(repository).crear(Mockito.any(Pelicula.class));  // crear una instancia falsa de pelicula
		Mockito.verify(actorRepository).crearListaActores(Mockito.anyList());  // crear una lista falsa
	}
	
	
	@Test
	void testExcepciones() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorRepository.findActoresByPeliculaId(Mockito.anyLong()))
			.thenThrow(IllegalArgumentException.class);
		
		// Al no tener actores la pelicula lanza una excepcion
		Exception ex = Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.findPeliculaByNombreConActores("La habitacion de al lado");
		});
		
		// Comprobar que la excepcion es IllegalArgumentException
		Assertions.assertEquals(IllegalArgumentException.class, ex.getClass());		
	}
	
	@Test
	void testExcepcionesIdNull() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS_ID_NULL);
		Mockito.when(actorRepository.findActoresByPeliculaId(Mockito.isNull()))
			.thenThrow(IllegalArgumentException.class);
		
		// Al no tener actores la pelicula lanza una excepcion
		Exception ex = Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.findPeliculaByNombreConActores("La habitacion de al lado");
		});
		
		// Comprobar que la excepcion es IllegalArgumentException
		Assertions.assertEquals(IllegalArgumentException.class, ex.getClass());		
	}
	
	// Matchers: se utilizan para asegurar que determinados argumentos se pasan al Mock
	// se pueden utilizar desde la clase Mockito o desde ArgumentMatchers
	@Test
	void testArgumentMatchers() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorRepository.findActoresByPeliculaId(Mockito.anyLong()))
			.thenReturn(Datos.ACTORES);
		service.findPeliculaByNombreConActores("La habitacion de al lado");
		
		Mockito.verify(repository).findAll();
		Mockito.verify(actorRepository).findActoresByPeliculaId(
				ArgumentMatchers.argThat(arg -> arg != null & arg.equals(3L)));
		Mockito.verify(actorRepository).findActoresByPeliculaId(ArgumentMatchers.eq(3L));
	}
	
	// Crear un ArgumentMatcher personalizado
	public static class MiArgumentMatcher implements ArgumentMatcher<Long>{
		
		private Long argument;

		@Override
		public boolean matches(Long argument) {
			this.argument = argument;
			return argument != null && argument > 0;
		}
		
		@Override
		public String toString() {
			return "ERROR: " + argument + " debe ser un numero positivo";
		}
		
	}
	
	@Test
	void testMiArgumentMatcher() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS_ID_NEGATIVO);
		Mockito.when(actorRepository.findActoresByPeliculaId(Mockito.anyLong()))
			.thenReturn(Datos.ACTORES);
		service.findPeliculaByNombreConActores("La habitacion de al lado");
		
		Mockito.verify(repository).findAll();
		Mockito.verify(actorRepository).findActoresByPeliculaId(
				ArgumentMatchers.argThat(new MiArgumentMatcher()));		
	}
	
	// Mockito nos ofrece la posibilidad de capturar los argumentos que le pasamos al mock
	// y poder comprobarlos.
	// 2 formas: ArgumentCaptor o @Captor
	@Test
	void testCapturarArgumentos() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		service.findPeliculaByNombreConActores("La habitacion de al lado");
		
		// Crear una instancia de ArgumentCaptor o una propiedad anotada como @Captor
		//ArgumentCaptor<Long> captor = ArgumentCaptor.forClass(Long.class);
		
		Mockito.verify(actorRepository).findActoresByPeliculaId(captor.capture());	
		Assertions.assertEquals(3L, captor.getValue());	
	}
	
	@Test
	void testDoThrow() {
		Pelicula peliculaNueva = Datos.PELICULA;
		peliculaNueva.setActores(Datos.ACTORES);
		
		// No podemos utilizar when cuando el metodo es de tipo void
		// The method when(T) in the type Mockito is not applicable for the arguments (void)
		//Mockito.when(actorRepository.crearListaActores(null)).thenThrow(IllegalArgumentException.class);
		
		// La alternativa es doThrow
		Mockito.doThrow(IllegalArgumentException.class).when(actorRepository)
			.crearListaActores(Mockito.anyList());
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.crear(peliculaNueva);
		} );
	}
	
	@Test
	void testDoCallRealMethod() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.doCallRealMethod().when(actorRepository).findActoresByPeliculaId(Mockito.anyLong());
		Pelicula pelicula = service.findPeliculaByNombreConActores("El 47");
		
		Assertions.assertEquals(1L, pelicula.getId());
	}
	
	// Spy es un hibrido entre los mocks y los objetos reales
	// Spy no funciona desde interfaces o clases abstractas, ha de ser una clase implementada
	@Test
	void testSpy() {
		PeliculaRepository peliculaRepository = Mockito.spy(PeliculaRepositoryImpl.class);
		ActorRepository actorRepository = Mockito.spy(ActorRepositoryImpl.class);
		PeliculaService peliculaService = new PeliculaServiceImpl(peliculaRepository, actorRepository);
		
		// Sigue llamando al objeto real
		//Mockito.when(actorRepository.findActoresByPeliculaId(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		// Ahora llama al mock
		Mockito.doReturn(Datos.ACTORES).when(actorRepository).findActoresByPeliculaId(Mockito.anyLong());
		
		Pelicula pelicula = peliculaService.findPeliculaByNombreConActores("El 47");
		
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
		Assertions.assertEquals(3, pelicula.getActores().size());
	}
	
	// Probar el orden cuando utilizo mas de una peticion
	@Test
	void testOrdenEnMocks() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		
		service.findPeliculaByNombreConActores("La Infiltrada");
		service.findPeliculaByNombreConActores("El 47");
		
		InOrder order = Mockito.inOrder(repository, actorRepository);
		order.verify(repository).findAll();
		order.verify(actorRepository).findActoresByPeliculaId(2L);
		
		order.verify(repository).findAll();
		order.verify(actorRepository).findActoresByPeliculaId(1L);
	}
	
	@Test
	void testNumeroInvocaciones() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		service.findPeliculaByNombreConActores("La Infiltrada");
		
		Mockito.verify(actorRepository).findActoresByPeliculaId(2L);
		Mockito.verify(actorRepository, Mockito.times(1)).findActoresByPeliculaId(2L);
		Mockito.verify(actorRepository, Mockito.atLeast(1)).findActoresByPeliculaId(2L);
		Mockito.verify(actorRepository, Mockito.atLeastOnce()).findActoresByPeliculaId(2L);
		Mockito.verify(actorRepository, Mockito.atMost(1)).findActoresByPeliculaId(2L);
		Mockito.verify(actorRepository, Mockito.atMostOnce()).findActoresByPeliculaId(2L);
	}
	

}




















