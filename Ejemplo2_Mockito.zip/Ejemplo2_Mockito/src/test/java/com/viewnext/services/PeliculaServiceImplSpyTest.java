package com.viewnext.services;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.viewnext.models.Datos;
import com.viewnext.models.Pelicula;
import com.viewnext.repositories.ActorRepositoryImpl;
import com.viewnext.repositories.PeliculaRepositoryImpl;

@ExtendWith(MockitoExtension.class)
public class PeliculaServiceImplSpyTest {
	
	@Spy
	PeliculaRepositoryImpl peliculaRepository;
	
	@Spy
	ActorRepositoryImpl actorRepository;
	
	@InjectMocks
	PeliculaServiceImpl peliculaService;
	
	@Test
	void testSpy() {
//		PeliculaRepository peliculaRepository = Mockito.spy(PeliculaRepositoryImpl.class);
//		ActorRepository actorRepository = Mockito.spy(ActorRepositoryImpl.class);
//		PeliculaService peliculaService = new PeliculaServiceImpl(peliculaRepository, actorRepository);
		
		// Sigue llamando al objeto real
		//Mockito.when(actorRepository.findActoresByPeliculaId(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		// Ahora llama al mock
		Mockito.doReturn(Datos.ACTORES).when(actorRepository).findActoresByPeliculaId(Mockito.anyLong());
		
		Pelicula pelicula = peliculaService.findPeliculaByNombreConActores("El 47");
		
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
		Assertions.assertEquals(3, pelicula.getActores().size());
	}

}
