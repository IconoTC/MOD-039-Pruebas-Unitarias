package com.viewnext.models;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestReporter;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.condition.DisabledIfEnvironmentVariable;
import org.junit.jupiter.api.condition.DisabledOnJre;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.viewnext.utils.PrecioNegativoException;

public class ProductoTest {
	
	Producto producto;
	
	@BeforeAll
	// Debe ser estatico
	static void inicioClasePrueba() {
		// Iniciamos un log para almacenar el resultado de las pruebas
		System.out.println("Empezamos a probar la clase ProductoTest");
	}
	
	@AfterAll
	// Debe ser estatico
	static void finClasePrueba() {
		// Cerramos el log
		System.out.println("Terminamos de probar la clase ProductoTest");
	}
	
	@BeforeEach
	void inicioMetodoTest() {
		producto = new Producto(1, "Impresora", 129.95);
		System.out.println("Producto creado para realizar la prueba");
	}
	
	@AfterEach
	void finalMetodoTest() {
		System.out.println("Prueba terminada");
	}
	
	@Nested
	@DisplayName("Probando los test de la clase producto")
	class ProductoPruebas{
		// Testear la descripcion de producto
		@Tag("producto")
		@Test
		@DisplayName("Probando la descripcion del producto")
		void testDescripcion() {
			// Producto producto = new Producto(1, "Impresora", 129.95);
			String descripcionReal = producto.getDescripcion();
			String descripcionEsperada = "Impresora";
			Assertions.assertEquals(descripcionEsperada, descripcionReal);
		}
		
		// Testear el precio de producto
		@Tag("producto")
		@Test
		@DisplayName("Probando el precio del producto")
		void testPrecio() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			//Assertions.assertTrue(producto.getPrecio() > 0);
			Assertions.assertFalse(producto.getPrecio() <= 0);
		}
		
		// Testear la igualdad de productos
		@Test
		@Disabled
		void testIgualdadProductos() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			Producto producto2 = new Producto(1, "Impresora", 129.95);
			Assertions.assertEquals(producto, producto2);
		}
		
		// Testear el precio del producto con excepcion personalizada
		@Test
		void testPrecioNegativoException() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			// Comprobar que lanza la excepcion al ser el precio negativo
//			Assertions.assertThrows(PrecioNegativoException.class, () -> {
//				producto.setPrecio(-10);
//			});
			
			// Comprobar el mensaje de la excepcion
			Exception exception = Assertions.assertThrows(PrecioNegativoException.class, () -> {
				producto.setPrecio(-10);
			});
			String msgReal = exception.getMessage();
			String msgEsperado = "El precio no puede ser negativo";
			Assertions.assertEquals(msgEsperado, msgReal);
		}
	}
	
	@Nested
	@DisplayName("Probando los test de la clase proveedor")
	class ProveedorPruebas{
		
		// Testear la relaccion entre producto y proveedor
		@Tag("producto")
		@Tag("proveedor")
		@Test
		void testRelaccionProductoProveedor() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			Producto producto2 = new Producto(2, "Scanner", 237.50);
			
			Proveedor proveedor = new Proveedor();
			proveedor.setNombre("HP");
			
			proveedor.addProducto(producto);
			proveedor.addProducto(producto2);
			
			/*
			Assertions.assertNotNull(proveedor.getProductos());
			
			Assertions.assertEquals(3, proveedor.getProductos().size(), "El proveedor debe tener 2 productos");
			
			// El proveedor HP tiene un producto Impresora
			Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
					.filter(prod -> prod.getDescripcion().equals("Impresora"))
					.findFirst()
					.get()
					.getDescripcion());
			*/
			
			// Forzar para que se evaluen todas las aserciones haya fallos en las primeras o no
			Assertions.assertAll(
					() -> Assertions.assertNotNull(proveedor.getProductos()),
					() -> Assertions.assertEquals(2, proveedor.getProductos().size(), "El proveedor debe tener 2 productos"),
					() -> Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
							.filter(prod -> prod.getDescripcion().equals("Impresora"))
							.findFirst()
							.get()
							.getDescripcion())
			);		
		}
	}
	
	@Nested
	@DisplayName("Habilitar o deshabilitar segun SO, JRE")
	class SO_JRE{
		@Test
		@EnabledOnOs(OS.WINDOWS)
		void testSOWindows() {
			System.out.println("Se ejecuta si el SO es Windows");
		}
		
		@Test
		@EnabledOnOs({OS.MAC, OS.LINUX})
		void testSOMacLinux() {
			System.out.println("Se ejecuta si el SO es Mac o Linux");
		}
		
		@Test
		@DisabledOnOs(OS.WINDOWS)
		void testNoSOWindows() {
			System.out.println("Deshabilitado si tu SO es Windows");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_8)
		void testSoloJava8() {
			System.out.println("Probando test en Java 8");
		}
		
		@Test
		@DisabledOnJre(JRE.JAVA_8)
		void testNoJava8() {
			System.out.println("Deshabilitado test en Java 8");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_21)
		void testSoloJava21() {
			System.out.println("Probando test en Java 21");
		}
	}
	
	@Nested
	@DisplayName("Pruebas de System Properties")
	class SystemProperties{
		
		@Test
		void verSystemProperties() {
			Properties properties = System.getProperties();
			properties.forEach((k,v) -> System.out.println(k + ": " + v));
		}
		
		// java.version: 1.8.0_111
		@Test
		@EnabledIfSystemProperty(named = "java.version", matches = "1.8.0_111")
		void testJavaVersion() {
			System.out.println("Tu version de java es 1.8.0_111");
		}
		
		// Tambien funciona con expresiones regulares
		@Test
		@EnabledIfSystemProperty(named = "java.version", matches = "1.8.*")
		void testJavaVersion2() {
			System.out.println("Tu version de java es 1.8.*");
		}
		
		@Test
		@EnabledIfSystemProperty(named = "ENV", matches = "dev")
		void testEnv() {
			System.out.println("Estamos en modo desarrollo");
		}
	}
	
	@Nested
	@DisplayName("Variables de entorno")
	class VariablesEntorno{
		
		@Test
		void verVariablesEntorno() {
			Map<String, String> variables = System.getenv();
			variables.forEach((k,v) -> System.out.println(k + ": " + v));
		}
		
		// COMMAND_MODE: unix2003
		@Test
		@EnabledIfEnvironmentVariable(named = "COMMAND_MODE", matches = "unix2003")
		void testCommandMode() {
			System.out.println("COMMAND_MODE: unix2003 --------------------------");
		}
		
		@Test
		@EnabledIfEnvironmentVariable(named = "PRUEBA", matches = "algo")
		void testPruebaAlgo() {
			System.out.println("PRUEBA: algo --------------------------");
		}
		
		@Test
		@EnabledIfEnvironmentVariable(named = "PRUEBA", matches = "dev")
		void testPruebaDev() {
			System.out.println("PRUEBA: dev --------------------------");
		}
		
		@Test
		@DisabledIfEnvironmentVariable(named = "PRUEBA", matches = "prod")
		void testPruebaProd() {
			System.out.println("PRUEBA: prod --------------------------");
		}
		
	}
	
	@Test
	@DisplayName("Probando el precio del producto con assumptions")
	void testAssumptions() {
		// Habilitar o deshabilitar un test o parte del test en funcion de una condicion
		// de forma programatica
		boolean esDev = "dev".equals(System.getProperty("ENV"));
		//Assumptions.assumeTrue(esDev);
		
		// Si solo queremos omitir parte del codigo, no la prueba completa
		// utilizamos assumingThat
		Assumptions.assumingThat(esDev, () -> {
			Assertions.assertFalse(producto.getPrecio() <= 0);
			Assertions.assertEquals(129.95, producto.getPrecio());
		});	
	}
	
	//@RepeatedTest(3)
	@RepeatedTest(value = 3, name = "Repeticion nº {currentRepetition} del total de {totalRepetitions}")
	void testRepetido(RepetitionInfo infoRep) {
		System.out.println("Estamos en la repeticion numero: " + infoRep.getCurrentRepetition());
		double numero = Math.random();
		System.out.println(numero);
		Assertions.assertNotNull(numero);
		Assertions.assertTrue(numero > 0);
	}
	
	// Test parametrizados: se trata de pasar varios datos como parametros y
	// asi poder relizar la prueba con cada uno de ellos
	//@ParameterizedTest
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@DisplayName("Probando el precio del producto")
	@ValueSource(doubles = {57, 0, -12})   // array de parametros
	void testPrecios(double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@DisplayName("Probando el precio del producto CsvSource")
	@CsvSource({"0,57", "1,0", "2,-12"})   // csv de parametros
	void testPreciosCsvSource(String idx, double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@DisplayName("Probando el precio del producto CsvFileSource")
	@CsvFileSource(resources = "/datos.csv")  // archivo csv de parametros
	void testPreciosCsvFileSource(double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);	
	}
	
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@DisplayName("Probando el precio del producto MethodSource")
	@MethodSource("queryPrecios")  // metodo que retorna lista de parametros
	void testPreciosMethodSource(double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
	
	}
	static List<Double> queryPrecios(){
		// Simulamos que lanzamos una query a la BBDD para traer la lista de precios
		return Arrays.asList(57.0, 0.0, -12.0);
	}
	
	// EJERCICIO
	/* 1.- Crear un productos.csv con 4 productos   id,descripcion,precio
	 * 2.- Testear la relaccion entre producto y proveedor
	 * 3.- utilizando test parametrizados
	 * */
	@ParameterizedTest
	@CsvFileSource(resources = "/productos.csv")
	void testProductosProveedor2(int id, String descripcion, double precio) {
		
		Proveedor proveedor = new Proveedor();
		proveedor.setNombre("HP");
		
		Producto producto = new Producto(id, descripcion, precio);
		proveedor.addProducto(producto);
		
		Assertions.assertEquals(1, proveedor.getProductos().size());
	}
	
	// TestInfo y TestReporter
	@Tag("producto")
	@Test
	@DisplayName("Probando la descripcion del producto")
	void testDescripcion(TestInfo info, TestReporter reporter) {
		
		System.out.println(info.getDisplayName() + " *********");
		System.out.println(info.getTestMethod() + " *********");
		System.out.println(info.getTags() +  " *********");
		
		reporter.publishEntry("Mensaje", "Esto es una prueba");
		
		// Producto producto = new Producto(1, "Impresora", 129.95);
		String descripcionReal = producto.getDescripcion();
		String descripcionEsperada = "Impresora";
		Assertions.assertEquals(descripcionEsperada, descripcionReal);
	}
	
	@Test
	@Timeout(value = 1000, unit = TimeUnit.MILLISECONDS)
	void testTimeOut() throws InterruptedException {
		// Queremos que la prueba falle cuando la ejecuccion supera 1 segundo
		
		// Forzamos al hilo espere 2 segundos
		Thread.sleep(2000);
	}
	
	// Hay otra forma de hacerlo
	@Test
	void testTimeOut2() throws InterruptedException {
		// Queremos que la prueba falle cuando la ejecuccion supera 1 segundo
		
		Assertions.assertTimeout(Duration.ofSeconds(1), () -> {
			// Forzamos al hilo espere 2 segundos
			Thread.sleep(2000);  // la prueba falla
			
			Thread.sleep(500); // pasa la prueba
		});
		
	}
}
















